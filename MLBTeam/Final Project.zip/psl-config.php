<?php

define("HOST", "localhost"); 			// The host you want to connect to. 
define("USER", "root"); 			// The database username. 
define("PASSWORD", ""); 	// The database password. 
define("DATABASE", "testdb");             // The database name.


define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");


define("SECURE", FALSE);    // For development purposes only!!!!
?>