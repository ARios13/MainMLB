<?php

$debug = 0;


/* 
$MLBTeams = array (
		"Arizona Diamondbacks",
		"Atlanta Braves",
		"Baltimore Orioles",
		"Boston Red Sox",
		"Chicago White Sox",
		"Chicago Cubs",
		"Cinncinnati Reds",
		"Cleveland Indians",
		"Colorado Rockies",
		"Detroit Tigers",
		"Miami Marlins",
		"Houston Astros",
		"Kansas City Royals",
		"Los Angeles Angels",
		"Los Angeles Dodgers",
		"Milwaukee Brewers",
		"Minnesota Twins",
		"New York Mets",
		"New York Yankees",
		"Oakland Athletics",
		"Philadelphia Phillies",
		"Pittsburgh Pirates",
		"San Diego Padres",
		"San Francisco Giants",
		"Seattle Mariners",
		"St. Louis Cardinals",
		"Tampa Bay Rays",
		"Texas Rangers",
		"Toronto Blue Jays",
		"Washington Nationals"
) */
?>