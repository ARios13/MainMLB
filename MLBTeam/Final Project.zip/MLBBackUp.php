<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<script src="MLBStats.js" type="text/javascript"></script>
<title>MLB Team Stats</title>
</head>
<body>
	<div id=center_box>
		<input type=radio name=team value=DBacks>Arizona Diamondbacks
		<input type=radio name=team value=Braves>Atlanta Braves <input
			type=radio name=team value=Orioles>Baltimore Orioles <br />
		<input type=radio name=team value=RSox>Boston Red Sox <input
			type=radio name=team value=WSox>Chicago White Sox <input
			type=radio name=team value=Cubs>Chicago Cubs <br /> <input
			type=radio name=team value=Reds>Cincinnati Reds <input
			type=radio name=team value=Indians>Cleveland Indians <input
			type=radio name=team value=Rockies>Colorado Rockies <br /> <input
			type=radio name=team value=Tigers>Detroit Tigers <input
			type=radio name=team value=Marlins>Miami Marlins <input
			type=radio name=team value=Astros>Houston Astros <br /> <input
			type=radio name=team value=Royals>Kansas
		City Royals <input type=radio 
			name=team value=Angels>Los Angeles Angels <input type=radio
			 name=team value=Dodgers>Los
		Angeles Dodgers <br /> <input type=radio
			 name=team value=Brewers>Milwaukee
		Brewers <input type=radio onclick="loadXMLDoc('Beijing');" name=team
			value=Twins>Minnesota Twins <input type=radio
			onclick="loadXMLDoc('Beijing');" name=team value=Mets>New
		York Mets <br /> <input type=radio onclick="loadXMLDoc('Beijing');"
			name=team value=Yankees>New York Yankees <input type=radio
			onclick="loadXMLDoc('Beijing');" name=team value=Athletics>Oakland
		Athletics <input type=radio onclick="loadXMLDoc('Beijing');" name=team
			value=Phillies>Philadelphia Phillies <br /> <input
			type=radio onclick="loadXMLDoc('Beijing');" name=team value=Pirates>Pittsburgh
		Pirates <input type=radio onclick="loadXMLDoc('Beijing');" name=team
			value=Padres>San Diego Padres <input type=radio
			onclick="loadXMLDoc('Beijing');" name=team value=Giants>San
		Francisco Giants <br /> <input type=radio
			onclick="loadXMLDoc('Beijing');" name=team value=Mariners>Seattle
		Mariners <input type=radio onclick="loadXMLDoc('Beijing');" name=team
			value=Cardinals>St Louis Cardinals <input type=radio
			onclick="loadXMLDoc('Beijing');" name=team value=Rays>Tampa
		Bay Rays <br /> <input type=radio onclick="loadXMLDoc('Beijing');"
			name=team value=Rangers>Texas Rangers <input type=radio
			onclick="loadXMLDoc('Beijing');" name=team value=BJays>Toronto
		Blue Jays <input type=radio onclick="loadXMLDoc('Beijing');" name=team
			value=Nationals>Washington Nationals <br />
</body>
</html>