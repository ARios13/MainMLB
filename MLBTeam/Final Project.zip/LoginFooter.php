<ul class="list-home">

</ul>
</div>
</div>
<div class="vline"></div>
</div>
</div>
</div>
</div>
<!--DO NOT Remove The Footer Links-->
<div class="footer">
	<p>
		� Copyright 2014. Designed by <a target="_blank"
			href="http://www.htmltemplates.net">HTML Templates</a>
	</p>
</div>
</div>
</div>

<!--DO NOT Remove The Footer Links-->
<!--Designed by-->
<a href="http://www.htmltemplates.net"> <img src="images/footnote.gif"
	class="copyright" alt="htmltemplates.net"></a>
<!--DO NOT Remove The Footer Links-->

</body>
</html>