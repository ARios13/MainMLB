<?php
require_once ("MLBHeader3.php");
?>
<html>
<body>The Official MLB Stats was a project done by Rafer Cooley and
	Antonio Rios for CSC3700. Our mission was to be able to deliever MLB team stats for
	the 2012 through 2013 season. Stats were choosen accordingly from a
	authentic website so that they are accurate as of the season end.
</body>
</html>
<?php require_once ("MLBFooter.php")?>